# animals > 2023-07-29 8:48am
https://universe.roboflow.com/yolo-m3bzt/animals-shwba

Provided by a Roboflow user
License: CC BY 4.0

